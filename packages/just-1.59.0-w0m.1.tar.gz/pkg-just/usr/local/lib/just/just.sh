#!/usr/bin/zsh
set -e

JUST_VERSION="1.59.0"
JUST_OVERLAY_VERSION="1.59.0-w0m.1"

find_justfile() {
  local dir="$PWD"
  while [ -n "$dir" ]; do
    for candidate in "$dir/justfile" "$dir/Justfile" "$dir/.justfile"; do
      if [ -f "$candidate" ]; then
        echo "$candidate"
        return 0
      fi
    done
    [ "$dir" = "/" ] && break
    dir="$(dirname "$dir")"
  done
  return 1
}

cmd="${1:-}"
case "$cmd" in
  -V|--version)
    echo "just $JUST_VERSION (webomage/just $JUST_OVERLAY_VERSION wasm32-linux-musl)"
    exit 0
    ;;
  --w0m-features)
    cat <<'FEATURES'
webomage/just overlay features active in TabLinux WASM:
  - fix/fmt-preserve-recipe-header-comment (casey/just#3773)
  - feat/multiline-doc-comments            (casey/just#2684)
  - feat/list-fallback-recipes             (casey/just#1500)
  - feat/wildcard-imports                  (casey/just#1885)
FEATURES
    exit 0
    ;;
esac

if command -v python3 >/dev/null 2>&1; then
  python3 - "$@" <<'PY'
import glob
import os
import re
import subprocess
import sys
from pathlib import Path

args = sys.argv[1:]

def find_justfile(start: Path):
    cur = start.resolve()
    while True:
        for name in ("justfile", "Justfile", ".justfile"):
            cand = cur / name
            if cand.is_file():
                return cand
        if cur.parent == cur:
            return None
        cur = cur.parent

def parse_justfile(path: Path, seen=None):
    if seen is None:
        seen = set()
    real = path.resolve()
    if real in seen or not real.is_file():
        return {"fallback": False, "recipes": {}}
    seen.add(real)
    lines = real.read_text(encoding="utf-8", errors="replace").splitlines()
    fallback = False
    recipes = {}
    doc_buf = []
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if re.match(r"^set\s+fallback(?:\s*:=\s*true)?\b", stripped):
            fallback = True
            doc_buf = []
            i += 1
            continue
        m_imp = re.match(r"^import(\?)?\s+['\"]([^'\"]+)['\"]", stripped)
        if m_imp:
            pat = m_imp.group(2)
            full_pat = str(real.parent / pat)
            matches = sorted(glob.glob(full_pat)) if any(c in pat for c in "*?[") else [full_pat]
            for match in matches:
                sub = parse_justfile(Path(match), seen)
                for k, v in sub["recipes"].items():
                    recipes.setdefault(k, v)
            doc_buf = []
            i += 1
            continue
        if stripped.startswith("#") and not stripped.startswith("#!"):
            doc_buf.append(stripped[1:].strip())
            i += 1
            continue
        if stripped.startswith("["):
            i += 1
            continue
        m_rec = re.match(r"^(@?[A-Za-z_][A-Za-z0-9_-]*)([^:\n]*):(.*)$", line)
        if m_rec and not line.startswith((" ", "\t")) and ":=" not in line.split(":", 1)[0]:
            raw_name = m_rec.group(1)
            quiet = raw_name.startswith("@")
            name = raw_name.lstrip("@")
            params = m_rec.group(2).strip()
            rest = m_rec.group(3).strip()
            body = []
            i += 1
            while i < len(lines) and (lines[i].startswith(" ") or lines[i].startswith("\t") or not lines[i].strip()):
                if lines[i].strip():
                    body.append(lines[i].strip())
                i += 1
            recipes[name] = {
                "name": name,
                "quiet": quiet,
                "params": params,
                "rest": rest,
                "doc": "\n".join(d for d in doc_buf if d is not None),
                "body": body,
                "source": str(real),
            }
            doc_buf = []
            continue
        doc_buf = []
        i += 1
    return {"fallback": fallback, "recipes": recipes, "path": real}

jf = find_justfile(Path.cwd())
if not jf:
    sys.stderr.write("error: no justfile found\n")
    sys.exit(1)

parsed = parse_justfile(jf)
recipes = parsed["recipes"]

if "--summary" in args:
    pub = [k for k in recipes if not k.startswith("_")]
    print(" ".join(pub))
    sys.exit(0)

if "-l" in args or "--list" in args:
    print("Available recipes:")
    for name, rec in recipes.items():
        if name.startswith("_"):
            continue
        sig = f"{name} {rec['params']}".strip()
        doc_lines = [d for d in rec["doc"].splitlines() if d] if rec["doc"] else []
        if len(doc_lines) > 1:
            for d in doc_lines:
                print(f"    # {d}")
            print(f"    {sig}")
        elif len(doc_lines) == 1:
            print(f"    {sig:<24} # {doc_lines[0]}")
        else:
            print(f"    {sig}")
    if parsed["fallback"] and jf.parent.parent != jf.parent:
        parent_jf = find_justfile(jf.parent.parent)
        if parent_jf and parent_jf != jf:
            p_parsed = parse_justfile(parent_jf)
            fb_recs = [r for k, r in p_parsed["recipes"].items() if not k.startswith("_") and k not in recipes]
            if fb_recs:
                print("\n    [fallback]")
                for rec in fb_recs:
                    sig = f"{rec['name']} {rec['params']}".strip()
                    doc_lines = [d for d in rec["doc"].splitlines() if d] if rec["doc"] else []
                    if doc_lines:
                        print(f"    {sig:<24} # {doc_lines[0]}")
                    else:
                        print(f"    {sig}")
    sys.exit(0)

if "--usage" in args or "--show" in args:
    flag = "--usage" if "--usage" in args else "--show"
    idx = args.index(flag)
    target = args[idx + 1] if idx + 1 < len(args) else None
    if not target or target not in recipes:
        sys.stderr.write(f"error: unknown recipe `{target}`\n")
        sys.exit(1)
    rec = recipes[target]
    if rec["doc"]:
        for line in rec["doc"].splitlines():
            print(f"# {line}" if line else "#")
    if flag == "--usage":
        sig = f"just {rec['name']} {rec['params']}".strip()
        print(f"Usage: {sig}")
    else:
        hdr = f"{rec['name']} {rec['params']}".strip() + ":"
        if rec["rest"]:
            hdr += f" {rec['rest']}"
        print(hdr)
        for b in rec["body"]:
            print(f"    {b}")
    sys.exit(0)

target = args[0] if args else next(iter(recipes), None)
if not target or target not in recipes:
    sys.stderr.write(f"error: justfile does not contain recipe `{target}`\n")
    sys.exit(1)
rec = recipes[target]
for line in rec["body"]:
    cmd_line = line.lstrip("@")
    if not rec["quiet"] and not line.startswith("@"):
        sys.stderr.write(f"{cmd_line}\n")
    rc = subprocess.call(cmd_line, shell=True)
    if rc != 0:
        sys.exit(rc)
PY
  exit $?
fi

echo "just $JUST_VERSION ($JUST_OVERLAY_VERSION)"
