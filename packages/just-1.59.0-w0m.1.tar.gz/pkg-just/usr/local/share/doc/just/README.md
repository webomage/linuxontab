# webomage/just 1.59.0-w0m.1 (TabLinux WASM)

Includes #3773 (`--fmt` recipe header comments), #2684 (multi-line doc comments),
#1500 (`--list` fallback recipes), and #1885 (wildcard `import '*.just'`).
