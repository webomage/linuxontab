# Orca (`orca` 1.4.214) for LinuxOnTab WASM

Orca is an AI-native multi-agent IDE and CLI orchestrator supporting the **Agent Client Protocol (ACP `2025-03-26`)**.

This package provides the `orca` CLI and ACP JSON-RPC 2.0 session/worktree orchestrator inside LinuxOnTab (`wasm32-linux-musl`).

## Quick Start

```sh
apk add orca
orca --version
orca status
orca acp session/new
orca worktree create feat-acp
```
