#!/usr/bin/zsh
set -e

ORCA_VERSION="1.4.214"
ACP_VERSION="2025-03-26"
ORCA_STATE_DIR="${ORCA_STATE_DIR:-$HOME/.orca-wasm}"
mkdir -p "$ORCA_STATE_DIR/worktrees" "$ORCA_STATE_DIR/sessions"

cmd="${1:-help}"
shift 2>/dev/null || true

case "$cmd" in
  -v|--version|version)
    echo "orca $ORCA_VERSION (wasm32-linux-musl / LinuxOnTab ACP $ACP_VERSION)"
    ;;
  status)
    echo "Orca WASM Host Runtime ($ORCA_VERSION)"
    echo "  Target       : wasm32-linux-musl (LinuxOnTab WALI)"
    echo "  ACP Protocol : $ACP_VERSION (JSON-RPC 2.0)"
    echo "  State Dir    : $ORCA_STATE_DIR"
    echo "  Project Scope: ${W0M_PROJECT:-w0m} (${W0M_PROJECT:-w0m}@webomage.com)"
    ;;
  acp)
    method="${1:-initialize}"
    project="${W0M_PROJECT:-w0m}"
    cat <<JSON
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "$method",
  "params": {
    "protocolVersion": "$ACP_VERSION",
    "clientInfo": {
      "name": "orca-linuxontab-wasm",
      "version": "$ORCA_VERSION"
    },
    "projectScope": {
      "projectId": "$project",
      "accountEmail": "$project@webomage.com",
      "crossProjectAccess": false
    }
  }
}
JSON
    ;;
  worktree)
    sub="${1:-list}"
    if [ "$sub" = "create" ] && [ -n "$2" ]; then
      mkdir -p "$ORCA_STATE_DIR/worktrees/$2"
      echo "Created Orca WASM worktree: $ORCA_STATE_DIR/worktrees/$2"
    else
      echo "Active Orca WASM worktrees in $ORCA_STATE_DIR/worktrees:"
      ls -1 "$ORCA_STATE_DIR/worktrees" 2>/dev/null || true
    fi
    ;;
  k7)
    mod="${1:-kb}"
    echo "Launching @k7 module '$mod' inside Orca WASM environment (project=${W0M_PROJECT:-w0m})..."
    ;;
  *)
    cat <<USAGE
orca $ORCA_VERSION — Agentic IDE CLI & ACP ($ACP_VERSION) Orchestrator for LinuxOnTab WASM

Usage:
  orca --version                  Show Orca WASM version
  orca status                     Inspect Orca WASM host & ACP state
  orca acp [method]               Emit or dispatch ACP 2025-03-26 JSON-RPC 2.0 envelope
  orca worktree [list|create <n>] Manage isolated agent worktrees
  orca k7 <module>                Launch @k7 module (kb, env, pwd, sec, obs, db, cf, git, pr)
USAGE
    ;;
esac
