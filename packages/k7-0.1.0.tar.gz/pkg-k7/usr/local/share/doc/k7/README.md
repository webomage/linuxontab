# `@k7` (`k7` 0.1.0) 10-Module Suite for LinuxOnTab WASM & Cloudflare Pages/R2

Provides the unified `k7` operator cockpit and all 10 `@k7` binaries (`k7`, `k7kb`, `k7env`, `k7pwd`, `k7c`, `k7spec`, `k7d`, `k7s`, `k7llm`, `k7tg`, `k7sol`) inside LinuxOnTab (`wasm32-linux-musl`).
