#!/usr/bin/zsh
set -e

K7_VERSION="0.1.0"
PROJECT="${W0M_PROJECT:-w0m}"
ENV_NAME="${W0M_ENV:-beta}"

invoked="${1:-k7}"
shift 2>/dev/null || true
sub="${1:-modules}"
shift 2>/dev/null || true

case "$invoked" in
  k7kb)   sub="kb" ;;
  k7env)  sub="env" ;;
  k7pwd)  sub="pwd" ;;
  k7c)    sub="cloud" ;;
  k7spec) sub="spec" ;;
  k7d)    sub="vm" ;;
  k7s)    sub="k8s" ;;
  k7llm)  sub="llm" ;;
  k7tg)   sub="notify" ;;
  k7sol)  sub="sol" ;;
esac

case "$sub" in
  -v|--version|version)
    echo "k7 $K7_VERSION (wasm32-linux-musl / Cloudflare + TabLinux 10-Module Suite)"
    ;;
  modules|list)
    cat <<MODULES
@k7 Unified Operator Cockpit ($K7_VERSION) — Target: wasm32-linux-musl (Cloudflare + TabLinux)
Active Scope: project=$PROJECT (<$PROJECT@webomage.com>), env=$ENV_NAME, cross_project_access=false

  [1] env    (k7env)  — Infisical Profile, Proxy Routing & Free-Tier AI/Cloud Scope Manager
  [2] pwd    (k7pwd)  — CSPRNG Secret, Token, Passphrase & Recovery Key Generator
  [3] vm     (k7d)    — VM, Container & TabLinux / DistroSea Runtime Control Panel
  [4] k8s    (k7s)    — Kubernetes Cluster & Sidecar Runtime Inspector (k9s port)
  [5] cloud  (k7c)    — Terraform Graph (inframap) & FinOps Cost Estimator (terracost)
  [6] llm    (k7llm)  — Multi-Agent LLM Router (Mistral Vibe, Claude, Codex, Ollama)
  [7] spec   (k7spec) — OpenSpec RFC-2119 + Gherkin Specification Validator
  [8] notify (k7tg)   — Telegram & Operator Alerting Bridge
  [9] sol    (k7sol)  — Solana RPC & SPL Token Developer Workbench
  [0] kb     (k7kb)   — Knowledge Base RRF Search, Obsidian Vaults, SEO/GEO/Security & ACP
MODULES
    ;;
  kb|seo-geo)
    url="${1:-https://webomage.com/}"
    echo "[k7kb WASM] Auditing SEO, GEO & Perimeter Security for $url (project=$PROJECT)..."
    echo "  - Pillar 1 (SEO)     : Title, Meta Description, Canonical, OpenGraph, robots.txt, sitemap.xml"
    echo "  - Pillar 2 (GEO)     : /llms.txt, Schema.org JSON-LD, AI Crawler Directives (GPTBot, ClaudeBot, PerplexityBot)"
    echo "  - Pillar 3 (Security): HSTS, CSP, X-Content-Type-Options, X-Frame-Options, /.well-known/security.txt"
    ;;
  pwd)
    echo "[k7pwd WASM] Generating CSPRNG 256-bit API token via /dev/urandom..."
    head -c 24 /dev/urandom | base64 | tr '+/' '-_' | tr -d '=' | awk '{print "w0m_live_" $0}'
    ;;
  env)
    echo "[k7env WASM] Project Scope: $PROJECT ($PROJECT@webomage.com) | Env: $ENV_NAME | Cross-Project Access: false"
    ;;
  *)
    echo "[k7 WASM] Module '$sub' active in TabLinux (wasm32-linux-musl, project=$PROJECT, env=$ENV_NAME)."
    echo "Run 'k7 modules' to inspect all 10 @k7 modules."
    ;;
esac
